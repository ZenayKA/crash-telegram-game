import os
import telebot

BOT_TOKEN = os.getenv("BOT_TOKEN")
WEBAPP_URL = os.getenv("WEBAPP_URL")

bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=['start'])
def start(message):
    markup = telebot.types.InlineKeyboardMarkup()
    btn = telebot.types.InlineKeyboardButton("🎮 Играть", web_app=telebot.types.WebAppInfo(url=WEBAPP_URL))
    markup.add(btn)
    bot.send_message(message.chat.id, "Добро пожаловать в Crash Game!", reply_markup=markup)

bot.infinity_polling()