let multiplier = 1.00;
let interval;

function startGame() {
    multiplier = 1.00;
    document.getElementById("multiplier").innerText = multiplier.toFixed(2) + "x";
    interval = setInterval(() => {
        multiplier += Math.random() * 0.05;
        document.getElementById("multiplier").innerText = multiplier.toFixed(2) + "x";
        if (Math.random() < 0.01) {
            clearInterval(interval);
            document.getElementById("multiplier").innerText = "💥 Обвал!";
        }
    }, 100);
}

function cashOut() {
    clearInterval(interval);
    alert("Ты забрал: " + multiplier.toFixed(2) + "x");
}

window.onload = startGame;