# Crash Telegram Game

Инструкция по запуску внутри.